package com.asm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ps32024Asm1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
