package com.asm.dto;

public class DailyReport {

}
