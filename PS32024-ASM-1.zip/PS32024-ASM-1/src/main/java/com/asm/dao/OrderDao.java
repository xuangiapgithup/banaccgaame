package com.asm.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.asm.entity.Order;
import com.asm.entity.Report;

public interface OrderDao extends JpaRepository<Order, Integer>{
	@Query("SELECT new com.asm.entity.Report(g.title, g.price, COUNT(DISTINCT o.user), SUM(od.price * od.quantity)) " +
		       "FROM OrderDetail od " +
		       "JOIN od.order o " +
		       "JOIN od.game g " +
		       "GROUP BY g.title, g.price")
		List<Report> getReport();


	
}