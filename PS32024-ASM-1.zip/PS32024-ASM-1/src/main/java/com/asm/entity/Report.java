package com.asm.entity;

import java.math.BigDecimal;

import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor

public class Report {
    private String game;
    private BigDecimal price;
    private long totalUsers;
    private BigDecimal totalRevenue;

    // Constructor cho các tham số cụ thể
    public Report(String game, BigDecimal price, long totalUsers, BigDecimal totalRevenue) {
        this.game = game;
        this.price = price;
        this.totalUsers = totalUsers;
        this.totalRevenue = totalRevenue;
    }
}
