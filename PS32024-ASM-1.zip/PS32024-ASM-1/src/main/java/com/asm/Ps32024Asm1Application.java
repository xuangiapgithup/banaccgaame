package com.asm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ps32024Asm1Application {

	public static void main(String[] args) {
		SpringApplication.run(Ps32024Asm1Application.class, args);
	}

}
